<html>
<head>
    <style>
        .customers {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
            font-size: 12px !important;
        }

        .customers td, #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        .customers tr:nth-child(even){background-color: #f2f2f2;}

        .customers tr:hover {background-color: #ddd;}

        .customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            padding-left: 6px;
            text-align: left;
            background-color: #04AA6D;
            color: white;
        }
    </style>
</head>
<body>

<h3>Summary</h3>

<table class="customers" >
    <thead>
    <tr>
        <th>Report</th>
        <th>Date</th>
        <th>Total</th>
        <th>Discount</th>
        <th>Vat</th>
        <th>Payable</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>Sales Report</td>
        <td><?php echo e($FormDate); ?> to <?php echo e($ToDate); ?></td>
        <td><?php echo e($total); ?></td>
        <td><?php echo e($discount); ?></td>
        <td><?php echo e($vat); ?></td>
        <td><?php echo e($payable); ?> </td>
    </tr>
    </tbody>
</table>


<h3>Details</h3>
<table class="customers" >
    <thead>
    <tr>
        <th>Customer</th>
        <th>Phone</th>
        <th>Email</th>
        <th>Total</th>
        <th>Discount</th>
        <th>Vat</th>
        <th>Payable</th>
        <th>Date</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->customer->name); ?></td>
            <td><?php echo e($item->customer->mobile); ?></td>
            <td><?php echo e($item->customer->email); ?></td>
            <td><?php echo e($item->total); ?></td>
            <td><?php echo e($item->discount); ?></td>
            <td><?php echo e($item->vat); ?></td>
            <td><?php echo e($item->payable); ?></td>
            <td><?php echo e($item->created_at); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>
</body>
</html>




<?php /**PATH C:\My-Laravel-Projects\Point-of-sales\resources\views/report/SalesReport.blade.php ENDPATH**/ ?>