<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-7 animated fadeIn col-lg-6 center-screen">
            <div class="card w-90  p-4">
                <div class="card-body">
                    <h4>SIGN IN</h4>
                    <br/>
                    <input id="email" placeholder="User Email" class="form-control" type="email"/>
                    <br/>
                    <input id="password"  placeholder="User Password" class="form-control" type="password"/>
                    <img src="<?php echo e(asset('images/login-eyes/eye.png')); ?>"
                     width="10%"
                     height="10%"
                    style="cursor: pointer; position: absolute;top:185px; left: 400px; width: 20px; height: 20px;"

                     id="togglePassword">
                <br /><br />
                    <br/>
                    <button onclick="SubmitLogin()" class="btn w-100 bg-gradient-primary">Next</button>
                    <hr/>
                    <div class="float-end mt-3">
                        <span>
                            <a class="text-center ms-3 h6" href="<?php echo e(url('/userRegistration')); ?>">Sign Up </a>
                            <span class="ms-1">|</span>
                            <a class="text-center ms-3 h6" href="<?php echo e(url('/sendOtp')); ?>">Forget Password</a>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<script>

async function SubmitLogin() {
    let email = document.getElementById('email').value;
    let password = document.getElementById('password').value;


    if (email.length === 0) {
        errorToast("Email is required");
    } else if (password.length === 0) {
        errorToast("Password is required");
    } else {
        showLoader();
        try {
            let res = await axios.post("/user-login", { email: email, password: password });
            console.log("Response:", res);

            hideLoader();
            if (res.status === 200 && res.data['status'] === 'success') {
                window.location.href = "/dashboard";
            } else {
                errorToast(res.data['message']);
            }
        } catch (error) {
            hideLoader();
            console.error("Error:", error);
            errorToast("An error occurred. Please try again.");
        }
    }
}

</script>

<script>
    const togglePassword =
          document.querySelector('#togglePassword');

    const password =
          document.querySelector('#password');

    togglePassword.
    addEventListener('click', function (e) {

        // Toggle the type attribute
        const type = password.getAttribute(
            'type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);

        // Toggle the eye slash icon
        if (togglePassword.src.match(
"<?php echo e(asset('images/login-eyes/eyeslash.png')); ?>")) {
            togglePassword.src =
"<?php echo e(asset('images/login-eyes/eye.png')); ?>";
        } else {
            togglePassword.src="<?php echo e(asset('images/login-eyes/eyeslash.png')); ?>";
        }
    });
</script>
<?php /**PATH C:\My-Laravel-Projects\Point-of-sales\resources\views/components/auth/login-form.blade.php ENDPATH**/ ?>