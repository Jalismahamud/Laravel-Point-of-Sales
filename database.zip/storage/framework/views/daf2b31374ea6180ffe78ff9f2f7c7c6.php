<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('components.auth.login-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\My-Laravel-Projects\Point-of-sales\resources\views/pages/auth/login-page.blade.php ENDPATH**/ ?>