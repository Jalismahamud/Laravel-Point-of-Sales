@extends('layout.sidenav-layout')
@section('content')
    @include('components.dashboard.summary')
@endsection

